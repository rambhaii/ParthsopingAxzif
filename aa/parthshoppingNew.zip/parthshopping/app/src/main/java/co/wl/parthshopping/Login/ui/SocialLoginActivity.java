package co.wl.parthshopping.Login.ui;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import co.wl.parthshopping.R;

public class SocialLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_social_login);
    }
}
