package co.wl.parthshopping.Filter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import co.wl.parthshopping.Category.dto.Category;
import co.wl.parthshopping.R;


public class ColourListAdapter extends RecyclerView.Adapter<ColourListAdapter.MyViewHolder> {

    private ArrayList<Category> transactionsList;
    private Context mContext;

    private int row_index=-1;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        CheckBox rating;

        public MyViewHolder(View view) {
            super(view);

            title =  view.findViewById(R.id.title);
            rating =  view.findViewById(R.id.select_brand);


        }
    }

    public ColourListAdapter(ArrayList<Category> transactionsList, Context mContext) {
        this.transactionsList = transactionsList;
        this.mContext = mContext;
     }

    @Override
    public  ColourListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.filter_category_sub_list_item, parent, false);

        return new ColourListAdapter.MyViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(final ColourListAdapter.MyViewHolder holder, final int position) {
        final Category operator = transactionsList.get(position);

        holder.title.setText(" "+operator.getColor_name());


        holder.rating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                row_index = position;
                notifyDataSetChanged();
                ((FilterActivity) mContext).ItemClick(operator.getId() ,"colour");


            }
        });




        if(row_index==position){
            holder.rating.setChecked(true);
        }else {
            holder.rating.setChecked(false);
        }

    }

    @Override
    public int getItemCount() {
        return transactionsList.size();
    }
}