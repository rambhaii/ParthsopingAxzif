package co.wl.parthshopping.Register.ui;

import android.content.Intent;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import co.wl.parthshopping.Login.ui.LoginActivity;
import co.wl.parthshopping.R;
import co.wl.parthshopping.Utils.Loader;
import co.wl.parthshopping.Utils.UtilMethods;

public class RegisteredActivity extends AppCompatActivity implements View.OnClickListener {

    Button tv_signup;
    TextView bt_login;
    Loader loader;
    EditText name,emailid,Phonenumber,Password,cPassword;
   String id="";
   String number="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registered);
        id=(getIntent().getStringExtra( "id"));

        number=(getIntent().getStringExtra("number"));
        getID();
    }

    private void getID() {

        loader = new Loader(this,android.R.style.Theme_Translucent_NoTitleBar);


        name=findViewById(R.id.name);
        emailid=findViewById(R.id.emailid);
        Phonenumber=findViewById(R.id.Phonenumber);
        Password=findViewById(R.id.Password);
        cPassword=findViewById(R.id.cPassword);
        Phonenumber.setText(number);


        bt_login=findViewById(R.id.bt_login);
        tv_signup=findViewById(R.id.tv_signup);

        tv_signup.setOnClickListener(this);
        bt_login.setOnClickListener(this);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setTitle("Register User");
        toolbar.setTitleTextColor(Color.WHITE);

        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }

    @Override
    public void onClick(View v) {


        if(v==tv_signup){
            if(name.getText().toString().isEmpty())
            {
                name.setError("please Enter Your Name");
                name.requestFocus();
                return;
            }
            if(emailid.getText().toString().isEmpty())
            {
                emailid.setError("please Enter Your E-mail");
                emailid.requestFocus();
                return;
            }
            if(Password.getText().toString().isEmpty())
            {
                Password.setError("please Enter Password");
                Password.requestFocus();
                return;
            }
            if(cPassword.getText().toString().isEmpty())
            {
                cPassword.setError("please Enter Confirm Password");
                cPassword.requestFocus();
                return;
            }
            if(!Password.getText().toString().equals(cPassword.getText().toString()))
            {
                Toast.makeText(this, "Password Does Not match", Toast.LENGTH_SHORT).show();
            }
            if (!UtilMethods.INSTANCE.isValidEmail(emailid.getText().toString().trim())){

                Toast.makeText(this, "please enter valid email id ", Toast.LENGTH_SHORT).show();
                return;
            }

            if (UtilMethods.INSTANCE.isNetworkAvialable(RegisteredActivity.this)) {
                loader.show();
                loader.setCancelable(false);
                loader.setCanceledOnTouchOutside(false);

                UtilMethods.INSTANCE.signup(RegisteredActivity.this, name.getText().toString().trim(),
                        emailid.getText().toString().trim(), Phonenumber.getText().toString().trim(),
                        Password.getText().toString().trim(), loader,RegisteredActivity.this,id);
            } else {
                UtilMethods.INSTANCE.NetworkError(RegisteredActivity.this, getResources().getString(R.string.network_error_title),
                        getResources().getString(R.string.network_error_message));
            }
        }

         if(v==bt_login){

             startActivity(new Intent(RegisteredActivity.this, LoginActivity.class));


        }


    }
}
