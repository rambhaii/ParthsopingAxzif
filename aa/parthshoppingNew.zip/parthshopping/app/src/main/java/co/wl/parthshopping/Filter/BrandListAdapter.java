package co.wl.parthshopping.Filter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

import co.wl.parthshopping.Category.dto.Category;
import co.wl.parthshopping.R;


public class BrandListAdapter extends RecyclerView.Adapter<BrandListAdapter.MyViewHolder> {

    private ArrayList<Category> transactionsList;
    private Context mContext;

    private int row_index=-1;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        CheckBox select_brand;

        public MyViewHolder(View view) {
            super(view);

            title =  view.findViewById(R.id.title);
            select_brand =  view.findViewById(R.id.select_brand);


        }
    }

    public BrandListAdapter(ArrayList<Category> transactionsList, Context mContext) {
        this.transactionsList = transactionsList;
        this.mContext = mContext;
     }

    @Override
    public BrandListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.filter_category_sub_list_item, parent, false);

        return new BrandListAdapter.MyViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(final BrandListAdapter.MyViewHolder holder, final int position) {
        final Category operator = transactionsList.get(position);
        holder.title.setText(" "+operator.getBrand_name());
        holder.select_brand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                row_index=position;
                  notifyDataSetChanged();

                ((FilterActivity) mContext).ItemClick(operator.getId() ,"Brand");
            }
        });
        if(row_index==position){
            holder.select_brand.setChecked(true);
        }else {
            holder.select_brand.setChecked(false);
        }
    }

    @Override
    public int getItemCount() {
        return transactionsList.size();
    }
}