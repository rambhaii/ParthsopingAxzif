package co.wl.parthshopping.Utils;


public enum ApplicationConstant {

    INSTANCE;

   // public String baseUrl = "https://www.parthshopping.com/";
    public String baseUrl = "http://axzif.com/";
    public String apikey = "api@parthshopping.com";
    public String baseUrtofferimage = "https://www.parthshopping.com/assets/img/offer_img/";
    public String prefNamePref = "roundPayPref";
    public String regRecentLoginPref = "recentLoginid";
    public String location = "location";
    public String locationreposeval = "locationreposeval";
     public String selectlocation = "selectlocation";
     public String Loginrespose = "Loginrespose";
     public String Categary = "Categary";
     public String one = "one";
     public String setWishList = "setWishList";
     public String address_id = "address_id";
     public String hitAddress = "hitAddress";
     public String sliderPref = "sliderPref";
}
