package co.wl.parthshopping.Location.dto;

public class GlobalData {


    public static double latitude ;
    public static double longitude ;
    public static String addressHeader ="";
    public static String address = "";



}
