package co.wl.parthshopping.Search.ui;

import android.graphics.Color;
import androidx.core.view.MenuItemCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.gson.Gson;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;

import co.wl.parthshopping.Category.dto.Category;
import co.wl.parthshopping.Category.dto.CategoryRespose;
import co.wl.parthshopping.Dashboard.ui.PaginationScrollListener;
import co.wl.parthshopping.Products.ui.ProductAdapter;
import co.wl.parthshopping.Products.ui.ProductAdapterFull;
import co.wl.parthshopping.R;
import co.wl.parthshopping.Utils.FragmentActivityMessage;
import co.wl.parthshopping.Utils.GlobalBus;
import co.wl.parthshopping.Utils.UtilMethods;

public class SearchActivity extends AppCompatActivity {

    RecyclerView recyclerView;
   EditText et_search;
    private ProgressBar loadingPB;
   ImageView back_btn;
   NestedScrollView nestedScroll;
    int page = 0, limit = 2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
       Getid();
    }

    private void Getid() {

//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
//        toolbar.setTitle("Search");
//        toolbar.setTitleTextColor(Color.WHITE);
//
//        setSupportActionBar(toolbar);
//        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                onBackPressed();
//            }
//        });

        UtilMethods.INSTANCE.liveSearchByName(SearchActivity.this,"",null);
        recyclerView=findViewById(R.id.recyclerView);
        et_search=findViewById(R.id.et_search);
        back_btn=findViewById(R.id.back_btn);
        loadingPB=findViewById(R.id.idPBLoading);
        nestedScroll=findViewById(R.id.nestedScroll);
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        et_search.requestFocus();

        et_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence.length()==0)
                {
                    UtilMethods.INSTANCE.liveSearchByName(SearchActivity.this,charSequence+"",null);
                }
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence.length()>3)
                {
                    UtilMethods.INSTANCE.liveSearchByName(SearchActivity.this,charSequence+"",null);
                }
               //
                //Toast.makeText(SearchActivity.this, ""+charSequence, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
//       et_search.

    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.search_menu, menu);
//        MenuItem searchViewItem = menu.findItem(R.id.action_search);
//        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchViewItem);
//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//                searchView.clearFocus();
//
//                return false;
//
//            }
//
//            @Override
//            public boolean onQueryTextChange(String newText) {
//
//                Log.e("newText","newText :  "+newText);
//
//                UtilMethods.INSTANCE.liveSearchByName(SearchActivity.this,newText.trim(),null);
//
//               // adapter.getFilter().filter(newText);
//
//
//
//                return false;
//            }
//        });
//        return super.onCreateOptionsMenu(menu);
//    }



    @Subscribe
    public void onFragmentActivityMessage(FragmentActivityMessage fragmentActivityMessage) {

        if (fragmentActivityMessage.getFrom().equalsIgnoreCase("products_detail")){
            dataParse(""+ fragmentActivityMessage.getMessage());
        }
    }

    ProductAdapterFull mAdapter;
    LinearLayoutManager mLayoutManager;
    ArrayList<Category> transactionsObjects = new ArrayList<>();
    CategoryRespose transactions = new CategoryRespose();

    public void dataParse(String respose) {

        Gson gson = new Gson();
        transactions = gson.fromJson(respose, CategoryRespose.class);
        transactionsObjects = transactions.getData();

        if (transactionsObjects.size() > 0) {
            mAdapter = new ProductAdapterFull(transactionsObjects, this,"main");
            mLayoutManager = new LinearLayoutManager(this);
            recyclerView.setLayoutManager(new GridLayoutManager(this,2));
            recyclerView.setItemAnimator(new DefaultItemAnimator());
            recyclerView.setAdapter(mAdapter);
            recyclerView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.GONE);
        }

    }





    @Override
    public void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            GlobalBus.getBus().register(this);
        }
    }

}


