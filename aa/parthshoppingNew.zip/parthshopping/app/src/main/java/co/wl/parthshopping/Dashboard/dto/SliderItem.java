package co.wl.parthshopping.Dashboard.dto;

public class SliderItem {
    private String imgUrl;

    // Constructor method.

    // Getter method
    public String getImgUrl() {
        return imgUrl;
    }

    // Setter method
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
}