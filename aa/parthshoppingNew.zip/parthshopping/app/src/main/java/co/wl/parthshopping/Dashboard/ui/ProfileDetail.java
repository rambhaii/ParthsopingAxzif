package co.wl.parthshopping.Dashboard.ui;

import android.content.SharedPreferences;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import co.wl.parthshopping.Login.dto.DataLogin;
import co.wl.parthshopping.R;
import co.wl.parthshopping.Utils.ApplicationConstant;

public class ProfileDetail extends AppCompatActivity {
    TextView tvname,tvmobile,tvemail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_detail);

        getId();


    }

    private void getId() {

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setTitle("Profile");
        toolbar.setTitleTextColor(Color.WHITE);

        setSupportActionBar(toolbar);
           tvname =findViewById(R.id.tvname);
           tvmobile=findViewById(R.id.tvmobile);
           tvemail=findViewById(R.id.tvemail);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        SharedPreferences myPreferences =  getSharedPreferences(ApplicationConstant.INSTANCE.prefNamePref, MODE_PRIVATE);
        String response = myPreferences.getString(ApplicationConstant.INSTANCE.Loginrespose, null);
        DataLogin balanceCheckResponse = new Gson().fromJson(response, DataLogin.class);
        String user_id=balanceCheckResponse.getUserId()+"";
        String name=balanceCheckResponse.getName();
        String mobile=balanceCheckResponse.getMobile();
        String email=balanceCheckResponse.getEmail();
        tvemail.setText(email);
        tvmobile.setText(mobile);
        tvname.setText(name);
        //Toast.makeText(this, "user_id"+user_id+"  name     "+name+"mobile : "+mobile, Toast.LENGTH_SHORT).show();
    }
}
